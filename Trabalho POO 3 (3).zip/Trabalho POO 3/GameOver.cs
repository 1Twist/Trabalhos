using Godot;
using System;

public partial class GameOver : Control
{
	public void IniciarPrecionado(){
		GetTree().ChangeSceneToFile("res://Menu Principal.tscn");
	}
	public void SairPrecionado(){
		GetTree().Quit();
	}

}
