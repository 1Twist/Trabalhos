using Godot;
using System;

public partial class hud : CanvasLayer
{
	public float cronometro;
	private int diamantes=0;
	private bool cronometroAtivo = false;
	private int min, seg, mil;
	private string cronometroFormatado, segundoFormatado, minutoFormatado;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		cronometro = 0;
		cronometroAtivo = true;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (cronometroAtivo)
		{
			cronometro += (float)delta;
			AtualizarPlacar(cronometro);

		}
	}
	public void AtualizarPlacar(float placar)
	{
		seg = (int)placar % 60;
		min = (int)placar / 60;
		mil = (int)(100 * (placar - min - seg));
		if (min < 10)
		{
			minutoFormatado = "0" + min;
		}
		else
		{
			minutoFormatado = "" + min;
		}
		if (seg < 10)
		{
			segundoFormatado = "0" + seg;
		}
		else
		{
			segundoFormatado = "" + seg;
		}
		cronometroFormatado = minutoFormatado + ":" + segundoFormatado + ":" + mil;
		GetNode<Label>("Tempo/TextoTempo").Text = cronometroFormatado;
		

	}
	public void AtualizarVida(int vida)
	{
		GetNode<Label>("Vidas/TextoVida").Text = "Vida: " + vida.ToString();
		
	}
	public void AtualizarDiamantes()
	{
		diamantes++;
		GetNode<Label>("Diamantes/TextoDiamantes").Text ="" + diamantes.ToString();
		if(diamantes==6){
			GetTree().ChangeSceneToFile("res://main.tscn");
		}
	}

}
