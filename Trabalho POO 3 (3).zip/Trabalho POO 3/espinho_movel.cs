using Godot;
using System;

public partial class espinho_movel : Area2D
{
	private int  contador = 0;
	[Export] private bool direcao = true;
	[Export] private bool progressivo = true;
	[Export] private int distanciaMaxima = 40;
	private int p;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		if (progressivo)
		{
			p = 1;
		}
		else
		{
			p = -1;
		}
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (direcao)
		{
			GlobalPosition += new Vector2(p, 0);
		}
		else
		{
			GlobalPosition += new Vector2(0, p);
		}
		if (contador >= distanciaMaxima)
		{
			contador = 0;
			p *= -1;
		}
		contador++;
	}

	private void OnBodyEntered(Node2D body)
	{
		if (body is jogador)
		{
			((jogador)body).ColidiuEspinho();
			((jogador)body).Vida--;
		}
	}
}

