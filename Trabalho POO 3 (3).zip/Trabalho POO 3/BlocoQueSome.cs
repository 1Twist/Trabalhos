using Godot;
using System;

public partial class BlocoQueSome : Area2D
{
	private StaticBody2D bloco;
	private Timer tempo;
	private bool pisou=false;
	private bool sumiu=false;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready(){
	tempo=GetNode<Timer>("Timer");
	bloco=GetNode<StaticBody2D>("StaticBody2D");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if(tempo.TimeLeft<0.1f&&pisou){
		pisou=false;
		sumiu=true;
		RemoveChild(bloco);
		tempo.Start(5);
		}
		else if(tempo.TimeLeft<0.1f&& sumiu){
			sumiu=false;
			AddChild(bloco);
		}
	}

	public void PisouNoBloco(Node2D body){
		if(body is jogador){
			tempo.Start(1);
			pisou=true;
		}
	}
}
