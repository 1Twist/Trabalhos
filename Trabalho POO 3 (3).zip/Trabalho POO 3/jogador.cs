using Godot;
using System;

public partial class jogador : CharacterBody2D
{
	private AnimatedSprite2D animate;
	public int Vida=3;
	private bool shouldJump = false;
	public const float Speed = 100.0f;
	private int DoubleJump = 0;
	public const float JumpVelocity = -300.0f;
	public const float InconditionalJumpVelocity = -500.0f;
	private AudioStreamPlayer somdePulo;
	private AudioStreamPlayer somdeAndar;
	private Vector2 savepoint;
	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();

	public override void _Ready()
	{
		animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		GetTree().CallGroup("GrupoHUD", "AtualizarVida", Vida);
		GD.Print("foi?");
	}
	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;
		somdePulo=GetNode<AudioStreamPlayer>("Sons/somdePulo");
		somdeAndar=GetNode<AudioStreamPlayer>("Sons/somdeAndar");


		// Add the gravity.
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		// Handle Jump.
		if (Input.IsActionJustPressed("ui_accept")||shouldJump)
		{
			if (IsOnFloor())
			{
				somdePulo.Play();
				velocity.Y = JumpVelocity;
				DoubleJump = 1;
			
			}
			else if (DoubleJump == 1)
			{
				somdePulo.Play();
				velocity.Y = JumpVelocity;
				DoubleJump = 0;
			}
			 else if (shouldJump||velocity.Y > 0 && Mathf.Abs(velocity.X) < 10) // Pulo incondicional
			{
			velocity.Y = InconditionalJumpVelocity;
			shouldJump = false; // Reseta a variável para não ficar pulando constantemente
			DoubleJump = 1;
			}
		}

		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			velocity.X = direction.X * Speed;
		}
		else
		{
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
		}

		Velocity = velocity;

		if (!IsOnFloor())
		{
			animate.Play("jump");
		}
		else
		{
			if (velocity.X != 0)
			{
				animate.Play("run");
				if (velocity.X >= 0)
				{
					animate.FlipH = true;
				}
				else
				{
					animate.FlipH = false;
				}
			}
			else
			{
				animate.Play("idle");
			}
		}

		MoveAndSlide();

		if (GlobalPosition.Y > 800)
		{
			GlobalPosition = GetSavePoint();
			Vida--;
			GetTree().CallGroup("GrupoHUD", "AtualizarVida", Vida);
		}
		if(Vida==0){
		GetTree().ChangeSceneToFile("res://Menu Principal.tscn");
		}

	}
	public void setInicialPoint(Vector2 pontoinicial){
		savepoint=pontoinicial;
	}
	public void setSavePoint()
	{
		savepoint = GlobalPosition;
	}

	public Vector2 GetSavePoint()
	{
		return this.savepoint;
	}

	public void ColidiuEspinho()
	{
		GlobalPosition = savepoint;
		Vida--;
		GetTree().CallGroup("GrupoHUD", "AtualizarVida", Vida);
		GD.Print("Espetado");
	}
	public void ColidiuPulo()
	{
		shouldJump = true;
	}
}
